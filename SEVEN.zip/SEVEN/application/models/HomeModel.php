<?php

class HomeModel extends CI_model
{
    public function register_user($data)
    {
        $insert = $this->db->insert('user', $data);
        if ($insert) {
            return true;
        } else {
            return false;
        }
    }
}
