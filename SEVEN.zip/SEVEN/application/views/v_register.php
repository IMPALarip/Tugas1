<!DOCTYPE html>

<head>
	<title>Register</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/signup.css"> -->
</head>

<body>
	<nav class="navbar" style="border-bottom:2px solid grey;">
		<a href="#" class="navbar-brand">
			<img class="logo" src="<?php echo base_url() ?>assets/img/Logo.png" alt="logo">
		</a>

		<ul class="nav justify-content-center">
			<li class="nav-item">
				<a class="nav-link" href="#">BERANDA</a>
			</li>
			<li class="nav-item">
				<a class="nav-link reverse" href="#">RENTAL PRODUK</a>
			</li>
			<li class="nav-item">
				<a class="nav-link reverse" href="#">SEWA JASA</a>
			</li>
			<li class="nav-item">
				<a class="nav-link reverse" href="#">TENTANG KAMI</a>
			</li>
		</ul>
		<a>
			<button type="button" class="btn btn-primary btn-sm">LOGIN</button>
			<button type="button" class="btn btn-primary reverse btn-sm">SIGNUP</button>
		</a>
	</nav>
	<div style="position: absolute; left: 50%;">
		<form class="child-container" action="<?php echo site_url() . 'home/register'; ?>" method="post">
			<div class="judul">
				<h1>Sign Up</h1>
				<h1 style="margin-left:15px; margin-top:-47px">_______</h1>
			</div>
			<div class="form-group">
				<label>Username</label>
				<input class="form-control" placeholder="" id="username" name="username" value="<?= set_value('username') ?>">
			</div>
			<div class=" form-group">
				<label>Email</label>
				<input type="email" class="form-control <?= form_error('email') ? 'input-error' : null ?>" placeholder="" id="email" name="email" value="<?= set_value('email') ?>">
				<?= form_error('email', '<span class="form-text text-danger"><i class="zmdi zmdi-alert-circle-o"></i> ', '</span>') ?>
			</div>
			<div class=" form-group">
				<label>Password</label>
				<input type="password" class="form-control <?= form_error('password') ? 'input-error' : null ?>" placeholder="" id="password" name="password">
				<?= form_error('password', '<span class="form-text text-danger"><i class="zmdi zmdi-alert-circle-o"></i> ', '</span>') ?>
			</div>
			<div class="form-group">
				<label>No.Hp</label>
				<input type="number" class="form-control" placeholder="" id="notel" name="notel" value="<?= set_value('notel') ?>">
			</div>
			<div class="form-group text-center">
				<button type="submit" class="btn btn-primary btn-center">SIGNUP</button>
			</div>
		</form>
	</div>
	<a>
		<img class="background" src="<?php echo base_url() ?>assets/img/Background.png">
	</a>
</body>
<style>
	.content {
		margin: auto;
		width: 50%;
		padding: 10px;
	}

	.logo {
		padding-left: 50px;
		justify-content: center;
		height: 30px;
	}

	.child-container {
		padding: 20px;
		border-radius: 10px;
		margin-top: 50px;
		height: 570px;
		width: 500px;
		position: relative;
		left: -50%;
		background-color: white;
	}

	.background {
		width: 100%;
		height: 100%;
	}

	.judul {
		margin-bottom: 10px;
		color: #338AC8;
	}

	.form-group {
		margin-bottom: 25px;
	}

	.form-control {
		border-width: 0 0 2px 0;
	}

	.btn {
		font-size: 15px;
		border-radius: 100px;
		width: 80px;
	}

	.nav-link.reverse {
		color: #767676;
	}

	.btn-primary.reverse {
		color: #007bff;
		background-color: white;
		border-color: #007bff;
	}
</style>

</html>