<?php

class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('HomeModel');
    }

    public function index()
    {
        $data['judul'] = 'SEVEN - Home';
        $this->load->view('v_register', $data);
    }

    public function register()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim|htmlspecialchars');
        $this->form_validation->set_rules('password', 'Password', 'required|trim|htmlspecialchars');
        $this->form_validation->set_rules('notel', 'Nomer Telepon', 'trim|htmlspecialchars');


        $this->form_validation->set_message('required', "{field} can't be blank.");
        $this->form_validation->set_message('valid_email', "{field} is invalid.");

        if ($this->form_validation->run() == false) {
            $data['judul'] = 'SEVEN - Home';
            $this->load->view('v_register', $data);
        } else {
            $data_insert = array(
                'username' => $this->input->post('username', true),
                'email' => $this->input->post('email', true),
                'password' => md5($this->input->post('password', true)),
                'nomerhp' => $this->input->post('notel', true)
            );
            $register = $this->HomeModel->register_user($data_insert);
            redirect('home/index');
        }
    }
}
